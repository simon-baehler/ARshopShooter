void Update()
    {
        if (tRig != null && shooterScript.isArrested())
        {
            tRig.AI.WorkingMemory.SetItem<bool>("varShooterArrested", true);
        }
        if (tRig != null && !shooterScript.isArrested())
        {
            tRig.AI.WorkingMemory.SetItem<bool>("varShooterArrested", false);
        }
        if (tRig != null)
        { 
            if (tRig.AI.WorkingMemory.GetItem<int>("speed") >= 5)
            {
                anim.SetBool("run", true);
                anim.SetBool("walk", false);
            }
            else
            {
                anim.SetBool("run", false);
                anim.SetBool("walk", true);
            }
        }   
    }
