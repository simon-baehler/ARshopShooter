﻿using RAIN.Core;
using RAIN.Serialization;
using RAIN.Navigation;
using RAIN.Navigation.Targets;
using UnityEngine;


public class Civillian_One_AI : MonoBehaviour
{
    AIRig tRig = null ;
    Animator anim = null;
    int speed;
    public GameObject shooter = null;
    private Shooter shooterScript;

    void onSaved()
    {
        tRig.AI.WorkingMemory.SetItem<string>("state", "saved");
    }
    void Start()
    {
        anim = GetComponent<Animator>();
        tRig = gameObject.GetComponentInChildren<AIRig>();
        shooterScript = shooter.GetComponent<Shooter>();
    }

    void Update()
    {
        if (tRig != null && shooterScript.isArrested())
        {
            tRig.AI.WorkingMemory.SetItem<bool>("varShooterArrested", true);
        }
        if (tRig != null && !shooterScript.isArrested())
        {
            tRig.AI.WorkingMemory.SetItem<bool>("varShooterArrested", false);
        }

        //Si notre vitesse est suppérieur ou égalle à 5 nous utiliserons l'animation de cours, dans le cas contraire nous utiliserons celle de la marche
        if (tRig != null)
        { 
            if (tRig.AI.WorkingMemory.GetItem<int>("speed") >= 5)
            {
                anim.SetBool("run", true);
                anim.SetBool("walk", false);
            }
            else
            {
                anim.SetBool("run", false);
                anim.SetBool("walk", true);
            }
        }   
    }

    //action se selection
    void OnSelect()
    {
        if (tRig != null && (tRig.AI.WorkingMemory.GetItem<string>("state") == "panique" || tRig.AI.WorkingMemory.GetItem<string>("state") == "normal"))
        {
            OnGoEscapePoint();
        }
    }
    void OnRun()
    {
        Destroy(gameObject);
        Destroy(this);

    }
    //Paraliser/Normal -> Escape Point
    void OnGoEscapePoint()
    {
        tRig.AI.WorkingMemory.SetItem<string>("state", "run");
    }
    void OnEndGame()
    {
        print("On end game");
    }
    void OnReset()
    {
        print("OnReset");
    }
}

