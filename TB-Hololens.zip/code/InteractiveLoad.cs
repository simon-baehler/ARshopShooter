﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class InteractiveLoad : HoloToolkit.Examples.InteractiveElements.Interactive
{
    public void LoadLevel(int level)
    {
        SceneManager.LoadScene(level);
    }
}
